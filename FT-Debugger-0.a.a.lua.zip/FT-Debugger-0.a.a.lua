#!/bin/bash

# Ask for file paths
read -p "Enter the path to the Lua file: " lua_file_path
read -p "Enter the path to the ASM file: " asm_file_path

# Validate file paths
if [ ! -f "$lua_file_path" ]; then
  echo "Error: Lua file not found at $lua_file_path"
  exit 1
fi

if [ ! -f "$asm_file_path" ]; then
  echo "Error: ASM file not found at $asm_file_path"
  exit 1
fi
-- [FlamesLLC @PROUDLY DEVELOPED IN FLAMESLLC TEST LABS CENTER  ] - [C] 20XX 
# Ask for output format
read -p "Enter the desired output format (us/eu/jp): " output_format

# Validate output format
if [ "$output_format" != "us" ] && [ "$output_format" != "eu" ] && [ "$output_format" != "jp" ]; then
  echo "Error: Invalid output format. Please enter either 'us', 'eu', or 'jp'"
  exit 1
fi

# Set the output file name based on the output format
output_file="output.$output_format.smc"

# Define the linker command
linker_command="lua_asm_linker"

# Create the object files
lua_object_file=$(mktemp)
asm_object_file=$(mktemp)

echo "Compiling Lua file..."
lua -c "$lua_file_path" -o "$lua_object_file"
echo "Lua compilation complete."

echo "Assembling ASM file..."
nasm -f elf "$asm_file_path" -o "$asm_object_file"
echo "ASM assembly complete."

# Link the object files
echo "Linking object files..."
$linker_command "$lua_object_file" "$asm_object_file" -o "$output_file"
echo "Linking complete."

# Clean up temporary files
rm "$lua_object_file"
rm "$asm_object_file"

echo "Output file generated: $output_file"
