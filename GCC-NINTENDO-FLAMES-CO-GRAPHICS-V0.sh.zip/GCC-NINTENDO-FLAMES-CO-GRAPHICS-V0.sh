#!/bin/bash

# This script compiles a C program using GCC on an ARM architecture.

# Copyright (c) 2023, Flames LLC. All rights reserved.

# This script is part of the NERD Dev team project.

# This script is licensed under the MIT License. See the LICENSE file for details.

# Get the name of the C program from the user.
echo "Enter the name of the C program: "
read program

# Check if the C program exists.
if [ ! -f "$program" ]; then
  echo "Error: The C program \"$program\" does not exist."
  exit 1
fi

# Compile the C program for the ARM architecture.
gcc -mcpu=arm1176jzf-s -o "$program" "$program.c"

# Generate the codebase for the output.
arm-none-eabi-objcopy -O binary "$program" "$program.bin"

## [PROUDLY BY FLAMES LLC 20XX]

# Display the output.
echo "The compiled C program has been generated."
